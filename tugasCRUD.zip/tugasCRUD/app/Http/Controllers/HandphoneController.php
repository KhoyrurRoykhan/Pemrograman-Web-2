<?php

namespace App\Http\Controllers;
use App\Models\Handphone;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class HandphoneController extends Controller
{
    public function create (){
        return view('createHandphone');
    }

    public function store(Request $request)
    {   

        $validatorDate = $request->validate([
            'namaInput' => 'required',
            'image'=> 'required|image|mimes:jpg,png,jpeg,gif,svg',
            'deskripsiInput' => 'required',
            'hargaInput' => 'required|numeric',
        ]);

        if($request->file('image')){
            $validatedDate['image']=$request->file('image')->store('post-image');
        }

        $namaInput = $request->input('namaInput');
        $image = $request->file('image')->store('post-image');
        $deskripsiInput = $request->input('deskripsiInput');
        $hargaInput = $request->input('hargaInput');


        // dd($request->input('')); 


        $query = DB::table('handphone')->insert([
            'nama' => $namaInput,
            'image' => $image,
            'deskripsi' => $deskripsiInput,
            'harga' => $hargaInput
        ]);

        if ($query) {
            return redirect()->route('Handphone.read')->with('success', 'Data Berhasil Ditambahkan');
        } else {
            return redirect()->route('Handphone.read')->with('failed', 'Data Gagal Ditambahkan');
        }
    }

    public function read(){
        $data['handphone'] = DB::table('handphone')->paginate(5);
        return view('readHandphone',$data);
    }

    public function edit($id)
    {
        $data['handphone'] = DB::table('handphone')->where('id', $id)->first();
        return view('editHandphone',$data);
    }

    public function update(Request $request, string $id)
    {   

        $validatorDate = $request->validate([
            'namaInput' => 'required',
            'image'=> 'required|image|mimes:jpg,png,jpeg,gif,svg',
            'deskripsiInput' => 'required',
            'hargaInput' => 'required|numeric',
        ]);

        $namaInput = $request->input('namaInput');
        $image = $request->file('image')->store('post-image');
        $deskripsiInput = $request->input('deskripsiInput');
        $hargaInput = $request->input('hargaInput');


        $query = DB::table('handphone')->where('id', $id)->update([
            'nama' => $namaInput,
            'image' => $image,
            'deskripsi' => $deskripsiInput,
            'harga' => $hargaInput
        ]);


        if ($query) {
            return redirect()->route('Handphone.read')->with('success', 'Data Berhasil Diupdate');
        } else {
            return redirect()->route('Handphone.read')->with('failed', 'Data Gagal Diupdate');
        }
    }

    public function destroy(string $id)
    {   
        $query = DB::table('handphone')->where('id', $id)->delete();


        if ($query) {
            return redirect()->route('Handphone.read')->with('success', 'Data Berhasil Dihapus');
        } else {
            return redirect()->route('Handphone.read')->with('failed', 'Data Gagal Dihapus');
        }
    }

    public function detail($id)
    {
        $data['handphone'] = DB::table('handphone')->where('id', $id)->first();
        return view('detailHandphone',$data);
    }
}

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">RPhoneCell</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link " aria-current="page" href="/">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="{{ route('dashboard.index')}}">Dashboard</a>
              </li>
              @can('admin')
              <li class="nav-item">
                <a class="nav-link" href="{{ route('Handphone.read')}}">CRUD Admin</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="{{ route('dashboard.showDataPengguna')}}">Data Pengguna</a>
              </li>
              @endcan
            </ul>
          </div>
          <div class="text-end d-flex align-items-center">
            <div class="user me-3"> 
                Halo, {{ Auth::user()->name }}
            </div>
            <div class="logout">
                <a href="{{ route('login.logout') }}" class="btn btn-danger">Logout</a>
            </div>
        </div>
        </div>
      </nav>

    <div class="container mt-3 text-center mb-5">
        <div class="">
            <div class="">
                <h1>Selamat Datang, {{ Auth::user()->name }}</h1>
                <br>
                <h4>Berikut Daftar Handphone Yang Tersedia :</h4>
            </div>
            <div class="container-fluid text-center">
              <br>
              <div class="row row-cols-4">
                @foreach ($handphone as $item)
                <div class="col border pt-3">
                  <p><img style="width: 75px" src="{{ asset('storage/'. $item->image)}}"></p>
                  <p style="font-size: 20px; font-family: Verdana, Geneva, Tahoma, sans-serif">{{$item->nama}}</p>
                  <p>{{$item->deskripsi}}</p>
                  <p>Rp. {{$item->harga}}</p>

                </div>
                @endforeach
              </div>
            </div>
        </div>
        <p>{{ $handphone->links() }}</p>
    </div>
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</body>
</html>

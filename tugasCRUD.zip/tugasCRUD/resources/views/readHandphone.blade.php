<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Show</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">RPhoneCell</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link " aria-current="page" href="/">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="{{ route('dashboard.index')}}">Dashboard</a>
              </li>
              @can('admin')
              <li class="nav-item">
                <a class="nav-link active" href="{{ route('Handphone.read')}}">CRUD Admin</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="{{ route('dashboard.showDataPengguna')}}">Data Pengguna</a>
              </li>
              @endcan
            </ul>
          </div>
          <div class="text-end d-flex align-items-center">
            <div class="user me-3"> 
                Halo, {{ Auth::user()->name }}
            </div>
            <div class="logout">
                <a href="{{ route('login.logout') }}" class="btn btn-danger">Logout</a>
            </div>
        </div>
        </div>
      </nav>


    <div class="container mt-3">
      <div class="row">
          <div class="col-md-10">

            @if (session('success'))
              <div class="alert alert-success alert-dismissible fade show" role="alert">
              {{ session('success') }}
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
            @endif

              <h1>Tabel Data Handphone</h1>
              <br>

              <a href="{{ route('Handphone.create')}}" class="btn btn-success">Tambah Data</a>

              <table class="table">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Image</th>
                        <th scope="col">Harga</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $no = 1;
                    @endphp
            
            
                    @foreach ($handphone as $index => $item)
                    <tr>
                        <th scope="row">{{ $index + $handphone->firstItem() }}</th>
                        <td>{{ $item->nama }}</td>
                        <td>
                          <div>
                            <img style="width: 50px" src="{{ asset('storage/'. $item->image)}}">
                          </div>
                          
                        </td>
                        <td>{{ $item->harga }}</td>
                        <td>
                            <a href="{{route('Handphone.detail', $item->id)}}" class="btn btn-info">Detail</a>
                            <a href="{{route('Handphone.edit', $item->id)}}" class="btn btn-primary">Edit</a>
                            
                            <form action="{{route('Handphone.hapus', $item->id)}}" method="POST" class="d-inline">
                            @csrf
                            @method('put')
                            <button class="btn btn-danger" onclick="confirm('Anda yakin akan meenghapus data ini?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
            
            
                    @php
                        $no++;
                    @endphp
                    @endforeach
                </tbody>
            </table>
            <p>{{ $handphone->links() }}</p>
          </div>
      </div>
  </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</body>
</html>

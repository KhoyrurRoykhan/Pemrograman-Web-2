<?php

use App\Http\Controllers\HandphoneController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\DashboardController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', [LoginController::class, 'show'])->name('login');
Route::post('/login', [LoginController::class, 'auth'])->name('login.auth');


Route::get('/register', [RegisterController::class, 'show'])->name('register.show');
Route::post('/register', [RegisterController::class, 'store'])->name('register.store');



Route::group(['middleware' => ['auth']], function () {
    Route::get('/logout', [LoginController::class, 'logout'])->name('login.logout');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard.index');
});

Route::group(['middleware' => ['admin']], function(){
    Route::get('/data-pengguna', [DashboardController::class, 'showDataPengguna'])->name('dashboard.showDataPengguna');
    Route::get('/readHandphone', [HandphoneController::class, 'read'])->name('Handphone.read');
    Route::get('/createHandphone', [HandphoneController::class, 'create'])->name('Handphone.create');
    Route::PUT('/store', [HandphoneController::class, 'store'])->name('Handphone.store');
    Route::get('/editHandphone/{id}', [HandphoneController::class, 'edit'])->name('Handphone.edit');
    Route::PUT('/editHandphone/{id}', [HandphoneController::class, 'update'])->name('Handphone.update');
    Route::PUT('/hapusHandphone/{id}', [HandphoneController::class, 'destroy'])->name('Handphone.hapus');
    Route::get('/detailHandphone/{id}', [HandphoneController::class, 'detail'])->name('Handphone.detail');
    Route::PUT('/hapus-data-pengguna/{id}', [DashboardController::class, 'destroy'])->name('User.hapus');
});

